#!/usr/bin/env bash
###############################################################################
# Phase 6 Global Shell Enhancements Contract Gate Script
#
# Validates command-center-v2.html includes:
# - Global Server Selector
# - Time Window selector
# - Global Search trigger
# - Alerts badge/button
# - System status indicator
###############################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0
RESULTS=()

log_pass(){ PASS_COUNT=$((PASS_COUNT+1)); RESULTS+=("${GREEN}PASS${NC} - $1"); }
log_fail(){ FAIL_COUNT=$((FAIL_COUNT+1)); RESULTS+=("${RED}FAIL${NC} - $1"); }
log_test(){ echo -e "${YELLOW}TEST${NC} - $1"; }

SHELL_FILE="$PROJECT_ROOT/services/ui/public/command-center-v2.html"

log_test "Checking command-center-v2.html exists..."
if [[ -f "$SHELL_FILE" ]]; then log_pass "command-center-v2.html exists"; else log_fail "command-center-v2.html missing"; fi

log_test "Checking required global header anchors..."
required=("global-server-select" "global-time-window" "global-search-trigger" "global-alerts-button" "global-alerts-badge" "global-system-status")
missing=()
for id in "${required[@]}"; do
  if ! grep -qE "id=[\"']${id}[\"']" "$SHELL_FILE" 2>/dev/null; then
    missing+=("$id")
  fi
done
if [[ ${#missing[@]} -eq 0 ]]; then
  log_pass "All required header anchors present: ${required[*]}"
else
  log_fail "Missing header anchors: ${missing[*]}"
fi

log_test "Checking global-context.js is included..."
if grep -q '/assets/global-context.js' "$SHELL_FILE" 2>/dev/null; then
  log_pass "Shell includes /assets/global-context.js"
else
  log_fail "Shell missing /assets/global-context.js"
fi

# Summary
echo ""
echo "================ Shell Gate Summary ================"
for r in "${RESULTS[@]}"; do echo -e "$r"; done

echo ""
echo "Pass: $PASS_COUNT  Fail: $FAIL_COUNT"

if [[ $FAIL_COUNT -gt 0 ]]; then
  exit 1
fi
