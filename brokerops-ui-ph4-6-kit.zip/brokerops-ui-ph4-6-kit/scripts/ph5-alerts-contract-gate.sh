#!/usr/bin/env bash
###############################################################################
# Phase 5 Alerts Contract Gate Script
#
# Validates Alerts UI presence and embed contract anchors.
# NOTE: This gate is UI-only and should remain fail-closed when anchors/routes
#       are missing.
###############################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

UI_PORT="${UI_PORT:-3000}"
UI_BASE_URL="http://localhost:${UI_PORT}"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0
RESULTS=()

log_pass(){ PASS_COUNT=$((PASS_COUNT+1)); RESULTS+=("${GREEN}PASS${NC} - $1"); }
log_fail(){ FAIL_COUNT=$((FAIL_COUNT+1)); RESULTS+=("${RED}FAIL${NC} - $1"); }
log_test(){ echo -e "${YELLOW}TEST${NC} - $1"; }

ALERTS_FILE="$PROJECT_ROOT/services/ui/public/alerts.html"
SHELL_FILE="$PROJECT_ROOT/services/ui/public/command-center-v2.html"

# 1) File exists
log_test "Checking alerts.html exists..."
if [[ -f "$ALERTS_FILE" ]]; then log_pass "alerts.html exists"; else log_fail "alerts.html missing"; fi

# 2) Shared CSS link
log_test "Checking alerts.html links shared ui.css..."
if [[ -f "$ALERTS_FILE" ]] && grep -q 'href="/assets/ui.css"\|href=\"\/assets\/ui.css\"' "$ALERTS_FILE"; then
  log_pass "alerts.html links /assets/ui.css"
else
  log_fail "alerts.html missing ui.css link"
fi

# 3) Required anchors
log_test "Checking alerts.html required DOM anchors..."
required=("alerts-table" "alerts-filters" "alerts-detail")
missing=()
for id in "${required[@]}"; do
  if ! grep -qE "id=[\"']${id}[\"']" "$ALERTS_FILE" 2>/dev/null; then
    missing+=("$id")
  fi
done
if [[ ${#missing[@]} -eq 0 ]]; then
  log_pass "All required anchors present: ${required[*]}"
else
  log_fail "Missing anchors: ${missing[*]}"
fi

# 4) Shell embeds alerts (non-blocking if you haven't added tab yet)
log_test "Checking shell references /alerts?embed=1..."
if [[ -f "$SHELL_FILE" ]] && grep -q '/alerts?embed=1' "$SHELL_FILE"; then
  log_pass "Shell embeds /alerts?embed=1"
else
  log_fail "Shell missing /alerts?embed=1 embed link"
fi

# 5) Route /alerts returns 200
log_test "Checking /alerts returns HTTP 200..."
HTTP_CODE=$(curl -sf -o /dev/null -w "%{http_code}" "${UI_BASE_URL}/alerts" 2>/dev/null || echo "000")
if [[ "$HTTP_CODE" == "200" ]]; then log_pass "/alerts returns HTTP 200"; else log_fail "/alerts returns HTTP $HTTP_CODE"; fi

# 6) Embed route contains anchors
log_test "Checking /alerts?embed=1 contains required anchors..."
EMBED=$(curl -sf "${UI_BASE_URL}/alerts?embed=1" 2>/dev/null || echo "")
if [[ -n "$EMBED" ]]; then
  ok=true
  for id in "alerts-table" "alerts-filters" "alerts-detail"; do
    echo "$EMBED" | grep -q "id=\"$id\"" || ok=false
  done
  if [[ "$ok" == "true" ]]; then log_pass "Embed contains anchors"; else log_fail "Embed missing one or more anchors"; fi
else
  log_fail "Failed to fetch /alerts?embed=1"
fi

# Summary
echo ""
echo "================ Alerts Gate Summary ================"
for r in "${RESULTS[@]}"; do echo -e "$r"; done

echo ""
echo "Pass: $PASS_COUNT  Fail: $FAIL_COUNT"

if [[ $FAIL_COUNT -gt 0 ]]; then
  exit 1
fi
