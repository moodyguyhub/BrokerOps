# BrokerOps UI — Phase 4–6 Implementation Kit (LP Accounts + Alerts + Global Shell)

## What this kit contains

- `services/ui/public/assets/global-context.js`
  - Cross-iframe global context: **server selector**, **time window**, **keyboard shortcuts**, **copy-to-clipboard**, **relative time**.
- `services/ui/public/alerts.html`
  - New Alerts page: grouped incidents, slide-in detail panel, acknowledge flow (critical requires note).
- `scripts/ph5-alerts-contract-gate.sh`
  - Gate 7: Alerts DOM + embed contract.
- `scripts/ph6-shell-contract-gate.sh`
  - Gate 8: Shell global header anchors + global-context include.

## Required edits (manual, small)

### A) Add global context script to UI assets

Copy:
- `services/ui/public/assets/global-context.js`  →  `BrokerOps/services/ui/public/assets/global-context.js`

### B) Add Alerts page

Copy:
- `services/ui/public/alerts.html` → `BrokerOps/services/ui/public/alerts.html`

### C) Update `command-center-v2.html` (shell) — add header controls + alerts tab

1) Ensure this script is included **once**:

```html
<script src="/assets/global-context.js"></script>
```

2) Add required header anchors (IDs must match Gate 8):

- `global-server-select`
- `global-time-window`
- `global-search-trigger`
- `global-alerts-button`
- `global-alerts-badge`
- `global-system-status`

3) Add Alerts tab entry that embeds:

```txt
/alerts?embed=1
```

4) Initialize shell context (example):

```html
<script>
  window.addEventListener('DOMContentLoaded', () => {
    BO_CTX.initShell({
      serverSelectId: 'global-server-select',
      timeWindowRootId: 'global-time-window',
      alertsButtonId: 'global-alerts-button',
      alertsBadgeId: 'global-alerts-badge',
      statusRootId: 'global-system-status',
      onNavigate: (tabKey) => {
        // map tabKey -> existing tab activation code
        // expected: orders | lp | alerts | dashboard
      }
    });
  });
</script>
```

### D) Update UI server routing (`services/ui/server.js`)

Add:
- Route `GET /alerts` to serve `public/alerts.html`.
- Proxy endpoints (minimal):
  - `GET /api/alerts`  (grouped incidents)
  - `POST /api/alerts/ack` (acknowledge)

If backend endpoints don’t exist yet, **return `{success:true,data:{incidents:[],unacked_count:0}}`** to keep UI stable.

### E) Wire Gate 7 and Gate 8 into CI workflow

Add two steps to `.github/workflows/ph1-rc-gate.yml` after Gate 6:

```yaml
- name: Gate 7 — Alerts Contract
  shell: bash
  run: |
    chmod +x ./scripts/ph5-alerts-contract-gate.sh
    ./scripts/ph5-alerts-contract-gate.sh

- name: Gate 8 — Shell Global Header Contract
  shell: bash
  run: |
    chmod +x ./scripts/ph6-shell-contract-gate.sh
    ./scripts/ph6-shell-contract-gate.sh
```

### F) LP Accounts redesign (bullet gauge + table toggle)

Option 1: manual merge into existing `lp-accounts.html` while preserving required anchors:
- `lp-summary`, `lp-filters`, `lp-table`, `lp-detail`, `lp-export-snapshot`, `lp-view-history` (Source: https://github.com/moodyguyhub/BrokerOps/commit/00e08f61997d1c4f55d22532299dd54ae904e927 )

Option 2: replace file with the provided template:
- `services/ui/public/lp-accounts.html.REPLACE`

CSS additions: append `docs/ui/ui-css-append.txt` to `services/ui/public/assets/ui.css` (or merge selectively).

