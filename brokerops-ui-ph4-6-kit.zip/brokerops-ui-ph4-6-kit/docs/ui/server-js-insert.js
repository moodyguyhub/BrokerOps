// Insert into services/ui/server.js (Unverified Hypothesis: exact server.js structure may differ)

// 1) Serve Alerts page
app.get('/alerts', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'alerts.html'));
});

// 2) Alerts API (fallback-safe)
app.get('/api/alerts', async (req, res) => {
  try {
    // If you have a real backend endpoint, proxy to it here.
    // Until then: keep UI stable.
    res.json({ success: true, data: { incidents: [], unacked_count: 0 } });
  } catch (e) {
    res.status(200).json({ success: true, data: { incidents: [], unacked_count: 0 }, note: 'fallback' });
  }
});

app.post('/api/alerts/ack', express.json(), async (req, res) => {
  // NOTE: fail-closed semantics live in backend; UI only records intent.
  res.json({ success: true });
});
