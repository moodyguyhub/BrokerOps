/* BrokerOps UI Global Context + Utilities (vanilla JS)
 * Purpose: provide cross-iframe server + time-window context, keyboard shortcuts,
 * relative time formatting, and copy-to-clipboard helpers.
 *
 * Integration (shell + pages):
 *  - Include: <script src="/assets/global-context.js"></script>
 *  - In shell: call BO_CTX.initShell({...}) after DOM ready.
 *  - In embed pages: call BO_CTX.initEmbedPage({...}) after DOM ready.
 */

(function () {
  'use strict';

  const STORAGE_KEY = 'brokerops_ui_ctx_v1';
  const DEFAULT_CTX = Object.freeze({
    server: 'all',
    window: '24h',
    q: ''
  });

  const MSG = Object.freeze({
    REQ: 'BROKEROPS_CTX_REQ',
    SYNC: 'BROKEROPS_CTX_SYNC',
    UPDATE: 'BROKEROPS_CTX_UPDATE',
    NAV: 'BROKEROPS_NAV'
  });

  /** @returns {{server:string, window:string, q?:string}} */
  function loadCtx() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return { ...DEFAULT_CTX };
      const parsed = JSON.parse(raw);
      return {
        server: typeof parsed.server === 'string' ? parsed.server : DEFAULT_CTX.server,
        window: typeof parsed.window === 'string' ? parsed.window : DEFAULT_CTX.window,
        q: typeof parsed.q === 'string' ? parsed.q : DEFAULT_CTX.q
      };
    } catch (_) {
      return { ...DEFAULT_CTX };
    }
  }

  /** @param {{server:string, window:string, q?:string}} ctx */
  function saveCtx(ctx) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(ctx));
  }

  /** @param {string} url */
  function withCtxParams(url) {
    const ctx = loadCtx();
    try {
      const u = new URL(url, window.location.origin);
      if (ctx.server && ctx.server !== 'all') u.searchParams.set('server', ctx.server);
      if (ctx.window) u.searchParams.set('window', ctx.window);
      if (ctx.q) u.searchParams.set('q', ctx.q);
      return u.toString();
    } catch (_) {
      // Fallback for relative URLs that URL() rejects in older environments
      const sep = url.includes('?') ? '&' : '?';
      const params = [];
      if (ctx.server && ctx.server !== 'all') params.push(`server=${encodeURIComponent(ctx.server)}`);
      if (ctx.window) params.push(`window=${encodeURIComponent(ctx.window)}`);
      if (ctx.q) params.push(`q=${encodeURIComponent(ctx.q)}`);
      return params.length ? `${url}${sep}${params.join('&')}` : url;
    }
  }

  function formatRelativeTime(ts) {
    const d = new Date(ts);
    const ms = d.getTime();
    if (Number.isNaN(ms)) return String(ts);

    const deltaSec = Math.floor((Date.now() - ms) / 1000);
    if (deltaSec < 0) return 'in future';
    if (deltaSec < 60) return `${deltaSec}s ago`;
    const deltaMin = Math.floor(deltaSec / 60);
    if (deltaMin < 60) return `${deltaMin}m ago`;
    const deltaHr = Math.floor(deltaMin / 60);
    if (deltaHr < 24) return `${deltaHr}h ago`;
    const deltaDay = Math.floor(deltaHr / 24);
    return `${deltaDay}d ago`;
  }

  function formatAbsoluteTime(ts) {
    const d = new Date(ts);
    const ms = d.getTime();
    if (Number.isNaN(ms)) return String(ts);
    // ISO with milliseconds
    return d.toISOString();
  }

  /**
   * Global context update.
   * - Shell: persists + broadcasts to all iframes
   * - Embed: persists locally + asks shell to update (so new ctx propagates)
   *
   * @param {{server?:string, window?:string, q?:string}} partial
   */
  function updateCtx(partial) {
    const next = { ...loadCtx(), ...partial };
    saveCtx(next);
    if (isShell()) {
      broadcast(next);
    } else {
      // ask shell to update + re-broadcast
      post(window.parent, MSG.UPDATE, partial);
    }
    return next;
  }

  /**
   * Attaches click-to-copy for any element with:
   *  - [data-copy="..."] OR
   *  - class="copy-id" + data-value="..."
   */
  function attachCopyHandlers(root = document) {
    const nodes = root.querySelectorAll('[data-copy], .copy-id[data-value]');
    nodes.forEach((el) => {
      if (el.__boCopyAttached) return;
      el.__boCopyAttached = true;
      el.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        const value = el.getAttribute('data-copy') || el.getAttribute('data-value') || el.textContent || '';
        if (!value) return;
        try {
          await navigator.clipboard.writeText(value);
          toast(`Copied: ${String(value).slice(0, 12)}${String(value).length > 12 ? '…' : ''}`);
        } catch (_) {
          // Clipboard may be blocked; degrade silently.
        }
      });
    });
  }

  function toast(message) {
    const existing = document.getElementById('bo-toast');
    if (existing) existing.remove();

    const t = document.createElement('div');
    t.id = 'bo-toast';
    t.className = 'bo-toast';
    t.textContent = message;
    document.body.appendChild(t);

    setTimeout(() => {
      t.classList.add('show');
      setTimeout(() => {
        t.classList.remove('show');
        setTimeout(() => t.remove(), 250);
      }, 1250);
    }, 10);
  }

  /** @param {Window} target */
  function post(target, type, payload) {
    try {
      target.postMessage({ type, payload }, '*');
    } catch (_) {
      // no-op
    }
  }

  function isShell() {
    return window === window.parent;
  }

  // ---------- Shell wiring ----------

  /**
   * @param {{
   *   serverSelectId: string,
   *   timeWindowRootId: string,
   *   alertsButtonId?: string,
   *   alertsBadgeId?: string,
   *   statusRootId?: string,
   *   activeIframeSelector?: string,
   *   onNavigate?: (tabKey:string) => void,
   * }} opts
   */
  function initShell(opts) {
    if (!isShell()) return;

    const serverSelect = document.getElementById(opts.serverSelectId);
    const timeRoot = document.getElementById(opts.timeWindowRootId);
    const alertsBtn = opts.alertsButtonId ? document.getElementById(opts.alertsButtonId) : null;
    const alertsBadge = opts.alertsBadgeId ? document.getElementById(opts.alertsBadgeId) : null;

    if (!serverSelect || !timeRoot) return;

    function broadcast(ctx) {
      // Broadcast to ALL iframes; pages can ignore when inactive.
      document.querySelectorAll('iframe').forEach((frame) => {
        if (frame && frame.contentWindow) post(frame.contentWindow, MSG.SYNC, ctx);
      });
    }

    function applyToHeader(ctx) {
      // server select
      if (serverSelect.value !== ctx.server) serverSelect.value = ctx.server;
      // time buttons
      timeRoot.querySelectorAll('[data-window]').forEach((btn) => {
        const w = btn.getAttribute('data-window');
        if (w === ctx.window) btn.classList.add('active');
        else btn.classList.remove('active');
      });
    }

    function setCtx(partial) {
      const next = updateCtx(partial);
      applyToHeader(next);
    }

    // initial
    const ctx0 = loadCtx();
    applyToHeader(ctx0);
    if (isShell()) broadcast(ctx0);

    // UI events
    serverSelect.addEventListener('change', () => setCtx({ server: serverSelect.value }));

    timeRoot.addEventListener('click', (e) => {
      const t = /** @type {HTMLElement} */ (e.target);
      const btn = t.closest('[data-window]');
      if (!btn) return;
      const w = btn.getAttribute('data-window');
      if (!w) return;
      setCtx({ window: w });
    });

    // keyboard shortcuts
    let gPressedAt = 0;
    window.addEventListener('keydown', (e) => {
      // Cmd/Ctrl+K: open search (delegate to shell if present)
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        const trigger = document.getElementById('global-search-trigger');
        if (trigger) {
          e.preventDefault();
          trigger.click();
        }
        return;
      }

      // '/' for search
      if (!e.ctrlKey && !e.metaKey && e.key === '/') {
        const trigger = document.getElementById('global-search-trigger');
        if (trigger) {
          e.preventDefault();
          trigger.click();
        }
        return;
      }

      // Esc closes any open panels (broadcast)
      if (e.key === 'Escape') {
        broadcast({ ...loadCtx(), __cmd: 'ESC' });
        return;
      }

      // G then O => navigate to Orders
      if (e.key.toLowerCase() === 'g') {
        gPressedAt = Date.now();
        return;
      }
      if (e.key.toLowerCase() === 'o' && gPressedAt && Date.now() - gPressedAt < 750) {
        gPressedAt = 0;
        // notify shell app
        if (typeof opts.onNavigate === 'function') opts.onNavigate('orders');
        // tell iframe too
        broadcast({ ...loadCtx(), __cmd: 'NAV', tab: 'orders' });
      }
    });

    // iframe requests
    window.addEventListener('message', (e) => {
      const msg = e.data;
      if (!msg || typeof msg !== 'object') return;
      if (msg.type === MSG.REQ) {
        post(e.source, MSG.SYNC, loadCtx());
      }
      if (msg.type === MSG.UPDATE) {
        // child requested ctx update (e.g., global search sets q)
        if (msg.payload && typeof msg.payload === 'object') setCtx(msg.payload);
      }
      if (msg.type === MSG.NAV) {
        if (typeof opts.onNavigate === 'function' && msg.payload && msg.payload.tabKey) {
          opts.onNavigate(String(msg.payload.tabKey));
        }
      }
    });

    // Alerts button (optional)
    if (alertsBtn && typeof opts.onNavigate === 'function') {
      alertsBtn.addEventListener('click', () => opts.onNavigate('alerts'));
    }

    // Basic alerts polling (non-fatal)
    if (alertsBadge) {
      async function poll() {
        try {
          const res = await fetch(withCtxParams('/api/alerts?status=unacked'));
          if (!res.ok) throw new Error('bad status');
          const json = await res.json();
          const count = (json && json.data && typeof json.data.unacked_count === 'number') ? json.data.unacked_count : 0;
          alertsBadge.textContent = String(count);
          alertsBadge.style.display = count > 0 ? 'inline-flex' : 'none';
        } catch (_) {
          // keep hidden on error
          alertsBadge.style.display = 'none';
        }
      }
      poll();
      setInterval(poll, 5000);
    }

    // (BO_CTX global API is attached at the end of this file)
  }

  // ---------- Embed page wiring ----------

  /**
   * @param {{
   *   onContext?: (ctx:any) => void,
   *   onEsc?: () => void,
   * }} opts
   */
  function initEmbedPage(opts = {}) {
    if (isShell()) return;

    // Request initial ctx
    post(window.parent, MSG.REQ, {});

    function handleCtx(ctx) {
      if (!ctx || typeof ctx !== 'object') return;
      // accept ctx and persist locally for same-origin iframe reloads
      const next = {
        server: typeof ctx.server === 'string' ? ctx.server : DEFAULT_CTX.server,
        window: typeof ctx.window === 'string' ? ctx.window : DEFAULT_CTX.window,
        q: typeof ctx.q === 'string' ? ctx.q : ''
      };
      saveCtx(next);
      if (typeof opts.onContext === 'function') opts.onContext(next);
    }

    window.addEventListener('message', (e) => {
      const msg = e.data;
      if (!msg || typeof msg !== 'object') return;
      if (msg.type === MSG.SYNC) {
        handleCtx(msg.payload);
      }
      // ESC broadcast comes through as payload.__cmd
      if (msg.type === MSG.SYNC && msg.payload && msg.payload.__cmd === 'ESC') {
        if (typeof opts.onEsc === 'function') opts.onEsc();
      }
      if (msg.type === MSG.SYNC && msg.payload && msg.payload.__cmd === 'NAV') {
        // ignore in embed pages
      }
    });

    // '/' focuses local search if present
    window.addEventListener('keydown', (e) => {
      if (!e.ctrlKey && !e.metaKey && e.key === '/') {
        const local = document.querySelector('[data-local-search]');
        if (local && 'focus' in local) {
          e.preventDefault();
          local.focus();
        }
      }
    });

    // embed pages use window.BO_CTX (global) which is attached at end of file
  }

  // export init fns
  window.BO_CTX = window.BO_CTX || {};
  // Core API (available in shell + embed)
  window.BO_CTX.get = loadCtx;
  window.BO_CTX.withParams = withCtxParams;
  window.BO_CTX.formatRelativeTime = formatRelativeTime;
  window.BO_CTX.formatAbsoluteTime = formatAbsoluteTime;
  window.BO_CTX.attachCopyHandlers = attachCopyHandlers;
  window.BO_CTX.toast = toast;
  window.BO_CTX.update = updateCtx;
  window.BO_CTX.navigate = (tabKey) => {
    if (!tabKey) return;
    if (isShell()) return; // shell navigation stays owned by initShell(opts.onNavigate)
    post(window.parent, MSG.NAV, { tabKey: String(tabKey) });
  };
  window.BO_CTX.MSG = MSG;
  window.BO_CTX.initShell = initShell;
  window.BO_CTX.initEmbedPage = initEmbedPage;

})();
